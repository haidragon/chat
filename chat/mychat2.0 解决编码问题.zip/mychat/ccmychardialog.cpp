#include "ccmychardialog.h"
#include "ui_ccmychardialog.h"
#include <QGroupBox>
#include <QVBoxLayout>
#include <QMessageBox>
CCmyCharDialog::CCmyCharDialog(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::CCmyCharDialog)
{
    ui->setupUi(this);
    ui->textEdit->setReadOnly(true);


//    //保存套节字
//    QTcpSocket *mytcpSocket;
//    int port;
//    QHostAddress *serverIP;

     this->port=4444;
     serverIP =new QHostAddress();
     serverIP->setAddress("192.168.2.186");
      mytcpSocket = new QTcpSocket(this);
     mytcpSocket->connectToHost(*serverIP,port);

     //检测链接信号
     connect(mytcpSocket,SIGNAL(connected()),this,SLOT(slotConnected()));
     //检测如果断开
     connect(mytcpSocket,SIGNAL(disconnected()),this,SLOT(slotDisconnected()));
     //检测如果有新可以读信号
     connect(mytcpSocket,SIGNAL(readyRead()),this,SLOT(dataReceived()));


      ccpersonList=new personList();
//    ui->widget_2->addItem(QToolBox_1);
//    ui->widget_2->addWidget(QToolBox_1);
//      QToolBox_1->show();


////////////////////////////////////////
 setWindowTitle(tr("My QQ"));
//***************初始化我的好友*****************
toolBtn1_1=new QToolButton;
toolBtn1_1->setText(tr("张三"));
//   toolBtn1_1->setIcon(QPixmap("res/11.bmp"));
//   toolBtn1_1->setIconSize(QPixmap("res/11.bmp").size());
toolBtn1_1->setAutoRaise(true);
toolBtn1_1->setToolButtonStyle(Qt::ToolButtonTextBesideIcon);

toolBtn1_2=new QToolButton;
toolBtn1_2->setText(tr("李四"));
//   toolBtn1_2->setIcon(QPixmap("res/12.bmp"));
//   toolBtn1_2->setIconSize(QPixmap("res/12.bmp").size());
toolBtn1_2->setAutoRaise(true);
toolBtn1_2->setToolButtonStyle(Qt::ToolButtonTextBesideIcon);

toolBtn1_3=new QToolButton;
toolBtn1_3->setText(tr("王五"));
//   toolBtn1_3->setIcon(QPixmap("res/13.bmp"));
//   toolBtn1_3->setIconSize(QPixmap("res/13.bmp").size());
toolBtn1_3->setAutoRaise(true);
toolBtn1_3->setToolButtonStyle(Qt::ToolButtonTextBesideIcon);

toolBtn1_4=new QToolButton;
toolBtn1_4->setText(tr("小赵"));
//   toolBtn1_4->setIcon(QPixmap("res/14.bmp"));
//   toolBtn1_4->setIconSize(QPixmap("res/14.bmp").size());
toolBtn1_4->setAutoRaise(true);
toolBtn1_4->setToolButtonStyle(Qt::ToolButtonTextBesideIcon);

toolBtn1_5=new QToolButton;
toolBtn1_5->setText(tr("小孙"));
//   toolBtn1_5->setIcon(QPixmap("res/15.bmp"));
//   toolBtn1_5->setIconSize(QPixmap("res/15.bmp").size());
toolBtn1_5->setAutoRaise(true);
toolBtn1_5->setToolButtonStyle(Qt::ToolButtonTextBesideIcon);
//***************添加我的好友*****************
QGroupBox *groupBox1=new QGroupBox;
QVBoxLayout *layout1=new QVBoxLayout(groupBox1);
layout1->setMargin(10);
layout1->setAlignment(Qt::AlignHCenter);
layout1->addWidget(toolBtn1_1);
layout1->addWidget(toolBtn1_2);
layout1->addWidget(toolBtn1_3);
layout1->addWidget(toolBtn1_4);
layout1->addWidget(toolBtn1_5);
layout1->addStretch();
//***************陌生人*********************
toolBtn2_1=new QToolButton;
toolBtn2_1->setText(tr("小王"));
//   toolBtn2_1->setIcon(QPixmap("res/21.bmp"));
//   toolBtn2_1->setIconSize(QPixmap("res/21.bmp").size());
toolBtn2_1->setAutoRaise(true);
toolBtn2_1->setToolButtonStyle(Qt::ToolButtonTextBesideIcon);

toolBtn2_2=new QToolButton;
toolBtn2_2->setText(tr("小张"));
//   toolBtn2_2->setIcon(QPixmap("res/22.bmp"));
//   toolBtn2_2->setIconSize(QPixmap("res/22.bmp").size());
toolBtn2_2->setAutoRaise(true);
toolBtn2_2->setToolButtonStyle(Qt::ToolButtonTextBesideIcon);
//***************添加陌生人*****************
QGroupBox *groupBox2=new QGroupBox;
QVBoxLayout *layout2=new QVBoxLayout(groupBox2);
layout2->setMargin(10);
layout2->setAlignment(Qt::AlignHCenter);
layout2->addWidget(toolBtn2_1);
layout2->addWidget(toolBtn2_2);
layout2->addStretch();
//***************黑名单*********************
toolBtn3_1=new QToolButton;
toolBtn3_1->setText(tr("小王"));
//   toolBtn3_1->setIcon(QPixmap("res/31.bmp"));
//   toolBtn3_1->setIconSize(QPixmap("res/31.bmp").size());
toolBtn3_1->setAutoRaise(true);
toolBtn3_1->setToolButtonStyle(Qt::ToolButtonTextBesideIcon);

toolBtn3_2=new QToolButton;
toolBtn3_2->setText(tr("小张"));
//   toolBtn3_2->setIcon(QPixmap("res/32.bmp"));
//   toolBtn3_2->setIconSize(QPixmap("res/32.bmp").size());
toolBtn3_2->setAutoRaise(true);
toolBtn3_2->setToolButtonStyle(Qt::ToolButtonTextBesideIcon);
//***************添加黑名单*****************
QGroupBox *groupBox3=new QGroupBox;
QVBoxLayout *layout3=new QVBoxLayout(groupBox3);
layout3->setMargin(10);
layout3->setAlignment(Qt::AlignHCenter);
layout3->addWidget(toolBtn3_1);
layout3->addWidget(toolBtn3_2);
layout3->addStretch();
//***************添加至主窗口*****************

ui->toolBox->setItemText(0,tr("我的分组1"));
ui->toolBox->setItemText(1,tr("我的分组2"));
ui->toolBox->addItem((QWidget*)groupBox1,tr("我的好友"));
ui->toolBox->addItem((QWidget*)groupBox2,tr("陌生人"));
ui->toolBox->addItem((QWidget*)groupBox3,tr("黑名单"));
ui->toolBox->addItem((QWidget*)ccpersonList,tr("qq"));


//ui->toolBox->removeItem(1);

}

CCmyCharDialog::~CCmyCharDialog()
{
    delete ui;

}

void CCmyCharDialog::set(QString use, QString pawssd)
{
    this->username=use;
    this->userpasswd=pawssd;
}

void CCmyCharDialog::setQTcpSocket(QTcpSocket * mysocket)
{
    this->mytcpSocket=mysocket;
}

void CCmyCharDialog::setAddandport(int port, QHostAddress *serverIP)
{
    this->serverIP=serverIP;
    this->port=port;
}

//
void CCmyCharDialog::closeEvent(QCloseEvent *event)
{
    exit(0);
//    emit myclose();
}


//发送
void CCmyCharDialog::on_pushButton_clicked()
{
    if(ui->textEdit_2->document()->isEmpty()){
        QMessageBox::information(this,tr("error"),tr("不能为空！！！"));
        return;
    }
//    //先清理文本框
//    ui->textEdit->clear();
//    //获取发送内容
    QString str=ui->textEdit_2->toPlainText();
//    //拼接内容
//    this->test +=this->username+":"+"\n"+str+'\n';
//    //输出内容
//    ui->textEdit->setPlainText(test);
//    //清理发送文本
//    ui->textEdit_2->clear();

    //发送内容
    QString jeshou="hai";
    QString msg=username+"%"+str+"%"+tr("fangsong")+"%"+jeshou;
//    mytcpSocket->close();
////    serverIP=
//    this->serverIP->setAddress("192.168.2.186");
//    this->port=4444;
//    mytcpSocket->connectToHost(*serverIP,port);
//    mytcpSocket->write(msg.toUtf8( ).data(),strlen(msg.toUtf8().data()));
//    mytcpSocket->writeData(msg.toUtf8(),msg.toUtf8().length());
      mytcpSocket->write(msg.toStdString().data());
//    mytcpSocket->write(msg.toLatin1(),msg.length());
//    qDebug("State:%d\n",mytcpSocket->state());
//    mytcpSocket->flush();


    qDebug()<<"发送 length"<<msg.toStdString().data();

//    qDebug()<<mytcpSocket<<msg.toUtf8().data()<<mytcpSocket->waitForBytesWritten();
}

/////////////////////////////////////////////////////////////////////////
//链接后
int length=0;
void CCmyCharDialog::slotConnected()
{

    QString msg=username+tr(":chating")+tr(":上线中");
//    length=strlen(msg.toUtf8().data());
//    mytcpSocket->write(msg.toUtf8( ).data(),strlen(msg.toUtf8().data()));
//   qDebug()<<"链接length"<<length;
//    bool QSctpSocket::writeDatagram(const QNetworkDatagram &datagram)

    mytcpSocket->write(msg.toStdString().data());
}


void CCmyCharDialog::slotDisconnected()
{
//    sendBtn->setEnabled(false);
//    enterBtn->setText(tr("进入聊天室"));
}

void CCmyCharDialog::dataReceived()
{
//    while(mytcpSocket->bytesAvailable()>0)
//    {
//        QByteArray datagram;
//        datagram.resize(mytcpSocket->bytesAvailable());

//        mytcpSocket->read(datagram.data(),datagram.size());

//        QString msg=datagram.data();
        while(mytcpSocket->bytesAvailable()>0)
        {
             QByteArray datagram;
//            int length = mytcpSocket->bytesAvailable();
            datagram.resize(mytcpSocket->bytesAvailable());
            char buf[1024];
            //全局 length
//            mytcpSocket->readData(datagram.data(),datagram.size());

            QString msg=QString::fromStdString(mytcpSocket->readAll().toStdString());
            qDebug()<<"接收length"<<datagram.size()<<msg;
            //先清理文本框
            ui->textEdit->clear();
            //获取发送内容
            QString str=ui->textEdit_2->toPlainText();
            //拼接内容
//            this->test +=this->username+":"+"\n"+str+'\n'+msg+'\n';
             this->test +=this->username+":"+"\n"+str+'\n'+msg+'\n';
            //输出内容
            ui->textEdit->setPlainText(test);
            //清理发送文本
            ui->textEdit_2->clear();
            qDebug()<<msg;
//            emit updateClients(msg,length);
        }
//    }
//        //先清理文本框
//        ui->textEdit->clear();
//        //获取发送内容
//        QString str=ui->textEdit_2->toPlainText();
//        //拼接内容
//        this->test +=this->username+":"+"\n"+str+'\n'+msg+'\n';
//        //输出内容
//        ui->textEdit->setPlainText(test);
//        //清理发送文本
//        ui->textEdit_2->clear();
//        qDebug()<<msg;
//    }
}


