#include "camthread.h"

Camthread::Camthread()
{
    cam     = NULL;
    timer   = new QTimer(this);
}

//Camthread::~Camthread()
//{
//    timer->stop();         // 停止读取数据。
//    cvReleaseCapture(&cam);//释放内存；
//    cvReleaseVideoWriter(&writer);

//}
void Camthread::startPlay()
{

    //打开摄像头从摄像头中获取视频
    cam = cvCreateCameraCapture(0);
    if(!cam)
    {

        emit sig_err("error");

    }
    else
    {
        //定时 50
        timer->start(50);
        start();
    }
}
void Camthread::run()
{
    // 时间到，读取当前摄像头信息
    double fps=30;
    frame = cvQueryFrame(cam);
    CvSize size=cvGetSize(frame);
    writer=cvCreateVideoWriter("Video from CAMERA.avi",CV_FOURCC('X','V','I','D'),
                               fps,size,1);
    connect(timer, SIGNAL(timeout()), this, SLOT(readFrame()));

}
void Camthread::readFrame( )
{
    frame = cvQueryFrame(cam);// 从摄像头中抓取并返回每一帧
    QImage image = QImage((const uchar*)frame->imageData, frame->width, frame->height,
                          QImage::Format_RGB888).rgbSwapped();
//写
    cvWriteFrame(writer,frame);
 //发送写完一张
    emit sig_GetOneFrame(image);

}
